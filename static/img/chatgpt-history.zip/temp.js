import { KJUR, KEYUTIL } from 'jsrsasign'
// 前端持有的私钥（Base64格式，不含头尾标记）
const PRIVATE_KEY = 'MIIEvgIBADANBgkqhkiG9w0BAQEFA...'
function generateNonce(length = 16) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let result = ''
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}
// Axios 请求拦截器 
service.interceptors.request.use(config => {
  const timestamp = Date.now().toString();
  const nonce = generateNonce(16);
  // 构建待签名字符串（与后端 buildSignString 规则一致） 
  let paramString = '';
  // GET 请求参数 
  if (config.params) {
    const sortedKeys = Object.keys(config.params).sort();
    sortedKeys.forEach(k => { paramString += `${k}=${config.params[k]}&`; });
  }
  // POST 请求体 
  if (config.data) {
    paramString += `body=${JSON.stringify(config.data)}&`;
  }
  paramString += `timestamp=${timestamp}&nonce=${nonce}`;
  // 用私钥签名 
  const prvKey = KEYUTIL.getKey(PRIVATE_KEY);     //  把 Base64 私钥转换成 RSA PrivateKey 对象
  const sig = new KJUR.crypto.Signature({ alg: 'SHA256withRSA' });
  sig.init(prvKey);
  sig.updateString(paramString);
  const sign = hextob64(sig.sign());
  // 放入请求头 
  config.headers['timestamp'] = timestamp;
  config.headers['nonce'] = nonce;
  config.headers['sign'] = sign;
  return config;
});
